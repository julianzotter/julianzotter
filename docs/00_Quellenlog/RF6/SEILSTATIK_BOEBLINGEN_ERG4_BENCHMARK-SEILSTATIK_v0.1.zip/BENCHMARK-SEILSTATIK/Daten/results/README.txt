Ergebnis-Exporte E6a (RF6_EXPORT_<stamp>_<RUN-ID>/). Nach Lauf schreibgeschuetzt. Hashes ins Quellenlog RF6 Par.3.
