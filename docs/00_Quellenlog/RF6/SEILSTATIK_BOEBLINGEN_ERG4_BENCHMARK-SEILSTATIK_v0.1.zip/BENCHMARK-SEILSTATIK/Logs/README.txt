Laufprotokolle (API_Log.json, RETOUR_LOG.json, *.log).
